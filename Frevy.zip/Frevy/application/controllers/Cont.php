<?php  

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * summary
 */
class Cont extends CI_Controller
{
    /**
     * summary
     */

    function __construct(){
    	parent:: __construct();
    	$this->load->model('data','d');
    }

   	function index(){
   		$data['tbl_data'] = $this->d->getdata();
   		$this->load->view('sample/index',$data);
   	}
}


?>