<?php  

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * summary
 */
class Data extends CI_Model
{
    /**
     * summary
     */
    public function getdata()
    {
    	$table = $this->db->table_exists('frevy_info');
    	if ($table) {
    		$query = $this->db->get('frevy_info');
    		if ($query->num_rows() > 0) {
    			return $query->result();
    		}
    		else {
    			return false;
    		}
    	}
    	else {
    		return false;
    	}
    }
}



?>