<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link href="https://fonts.googleapis.com/css2?family=Castoro&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Bubblegum+Sans&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Telex&display=swap" rel="stylesheet">
	<title><?php if($tbl_data){
		foreach($tbl_data as $data){
			echo $data->fname." ".$data->lname;
		}
	} ?></title>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css')?>">
</head>
<body>

	<!-- header -->
	<header>
		<div class="head">
			<div class="img">
				<ul>
					<li><a href="<?php echo base_url('Cont/index'); ?>" style="color: white;">Personal Information</a></li>
				</ul>
			</div>
			<div class="form">
				<ul>
					<li><a href="#">Home</a></li>
					<li><a href="#">Profile</a></li>
					<li><a href="#">Personal</a></li>
					<li><a href="#">About</a></li>
				</ul>
			</div>
		</div>
	</header>
	<!-- end of header -->


	<!-- flex -->
	<div class="box">
		<div class="box_content">
			<div class="content">
				<img src="<?php echo base_url();?>assets/images/mads.jpg" alt="Images" width="200" height="300">
				<div class="btn">
					<button title="Add Friend">Add Me</button>
					<button title="Message">Message</button>
				</div>
			</div>
			<div class="text">
				<p>
					<?php 
							if ($tbl_data) {
								foreach ($tbl_data as $data) {
								    echo $data->txt;
								}
							}
						?>
				</p>
				<div class="info">
					<ul>
						<li><span>Name: <?php 
							if ($tbl_data) {
								foreach ($tbl_data as $data) {
								    echo $data->fname." ".$data->lname;
								}
							}
						?></span></li>
						<li><span>Email: <?php 
							if ($tbl_data) {
								foreach ($tbl_data as $data) {
								    echo $data->email;
								}
							}
						?></span></li>
						<li><span>Contact: <?php 
							if ($tbl_data) {
								foreach ($tbl_data as $data) {
								    echo $data->contact;
								}
							}
						?></span></li>
						<li><span>Skills: Sing, Dance, Photo editing  </span></li>
						<li><span>Motto: <?php 
							if ($tbl_data) {
								foreach ($tbl_data as $data) {
								    echo $data->motto;
								}
							}
						?></span></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<!-- end of flex -->
	
</body>
</html>