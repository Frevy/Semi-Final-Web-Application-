-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 01, 2020 at 02:34 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `frevy`
--

-- --------------------------------------------------------

--
-- Table structure for table `frevy_info`
--

CREATE TABLE `frevy_info` (
  `id` int(10) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `motto` varchar(50) NOT NULL,
  `txt` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `frevy_info`
--

INSERT INTO `frevy_info` (`id`, `fname`, `lname`, `email`, `contact`, `motto`, `txt`) VALUES
(1, 'Frevy Lhanz', 'Plasabas', 'frevy.plasabas09@gmail.com', '09450710902', 'Put God first in everything you\'ll do', 'Hi! I’m Frevy Lhanz T. Plasabas or just call me “frev”.  I currently live in Purok 4 Barangay Sumilihon, Butuan City, Agusan del Norte. I graduated at Father Urios High School of Ampayon Incorporated in my High School years. I recently have my first course (Bachelor of Science in Nursing) at Father Saturnino Urios University way back 2013-2016 (October). Unfortunately due to financial matters I wasn’t able to finished it and ended up my 3 years as a Student Nurse. But I believed in this bible verse (Provers 16:4 “The Lord has made everything for its purpose”). Within that month (October) I decided to apply for a job. By God’s grace this job I had today is the only job that I have applied with. Until this time I am working as a Photo Editor for 4 years and became an Admin at Digital Photo Image Studio/ Photo Len’s Studio. \r\nApparently the applications or software I usually used are Lightroom and Adobe Photoshop in doing my job.');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
